package mispis;

import java.util.Collection;

public class Institute {

    public String name;
    public String address;
    Collection<Faculty> faculties;

    public Institute(String name, String address, Collection<Faculty> faculties) {
        this.name = name;
        this.address = address;
        this.faculties = faculties;
    }

    @Override
    public String toString() {
        return "Institute{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", faculties=" + faculties +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setStipend() {
    }

    public void giveStipend() {
    }

    public void giveHighStipend() {
    }

    public void setVacationDate() {
    }

    public void sendExchangeStudents() {
    }

}