package mispis;

import com.sun.source.tree.Tree;

import java.util.Collection;

public class Faculty {

    public Dean dean;
    public String name;
    public Collection<Department> departments;

    public Faculty(Dean dean, String name, Collection<Department> departments) {
        this.dean = dean;
        this.name = name;
        this.departments = departments;
    }

    @Override
    public String toString() {
        return "Faculty{" +
                "dean=" + dean +
                ", name='" + name + '\'' +
                ", departments=" + departments +
                '}';
    }

    public Dean getDean() {
        return dean;
    }

    public void setDean(Dean dean) {
        this.dean = dean;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void findStudent() {}
    public void setSessionDate() {}
    public boolean ifTakeVacation() {
        return true;
    }

}