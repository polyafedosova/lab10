package mispis;

public class Lecturer extends ResearchAssociate {

    public Lecturer(int ssNo,
                    float workExperience,
                    String name,
                    String email,
                    int counter) {
        super(name, "");
        this.name = name;
        this.counter = counter;
        this.workExperience = workExperience;
        this.ssNo = ssNo;
        this.email = email;
    }


    @Override
    public String toString() {
        return "Lecturer{" +
                "ssNo=" + ssNo +
                ", workExperience=" + workExperience +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", counter=" + counter +
                '}';
    }

    public void takeVacation() {
    }

    public void takeSick() {
    }

}