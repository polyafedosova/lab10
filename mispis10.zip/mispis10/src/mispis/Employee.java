package mispis;

public abstract class Employee {


	public int ssNo;
	public float workExperience;
	public String name;
	public String email;
	public int counter;

}