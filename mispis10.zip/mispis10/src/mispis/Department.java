package mispis;

import java.util.Collection;

public class Department {

    public String name;
    public Collection<Course> courses;


    public Department(String name, Collection<Course> courses) {
        this.name = name;
        this.courses = courses;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addTeacher() {}
    public void deleteTeacher() {}
    public void updateHeadOfDepartment() {}

    @Override
    public String toString() {
        return "Department{" +
                "name='" + name + '\'' +
                ", courses=" + courses +
                '}';
    }
}
