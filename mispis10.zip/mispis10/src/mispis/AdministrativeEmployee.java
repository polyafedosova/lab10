package mispis;

public class AdministrativeEmployee extends Employee {


    public AdministrativeEmployee(String name) {
        this.name = name;
    }

    public void setName(String name) {
         this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void buyNewEquipment() {}

    @Override
    public String
    toString() {
        return "AdministrativeEmployee{" +
                "name='" + name + '\'' +
                '}';
    }
}