package mispis;

public class Dean extends Employee {
    public Dean(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Dean{" +
                "name='" + name + '\'' +
                '}';
    }

    public void makeTransferBudget() {}

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
