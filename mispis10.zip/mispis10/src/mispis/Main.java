package mispis;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {
        Collection<Lecturer> lecturers = new LinkedList<>();
        Collection<Course> courses = new LinkedList<>();
        Collection<Department> departments = new LinkedList<>();
        Collection<Faculty> faculties = new LinkedList<>();

        Lecturer lecture = new Lecturer(1, 44, "Власов.С.В", "vlasov@yandex.ru", 4);
        lecturers.add(lecture);

        AdministrativeEmployee admin = new AdministrativeEmployee("Федосова.П.О");

        Project project = new Project("БРС", new Date(1111111111), new Date(222222222));

        ResearchAssociate assistant = new ResearchAssociate("Сычев.А.В", "IS");

        Dean dean = new Dean("Крыловецкий.A.A");

        Participation participation = new Participation(85);

        Course course = new Course(lecturers, "МиСПИС", 34, 100);
        courses.add(course);

        Department department = new Department("Информационные системы", courses);
        departments.add(department);

        Faculty faculty = new Faculty(dean, "ФКН", departments);
        faculties.add(faculty);

        Institute institute = new Institute("ВГУ", "Университетская площадь 1", faculties);


        System.out.println(lecture);
        System.out.println(admin);
        System.out.println(project);
        System.out.println(assistant);
        System.out.println(dean);
        System.out.println(participation);
        System.out.println(course);
        System.out.println(department);
        System.out.println(faculty);
        System.out.println(institute);

    }
}
